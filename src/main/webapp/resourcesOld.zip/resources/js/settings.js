function Menu(){
	this.categories = 'undefined';
	this.mediaProviders = 'undefined';
	
	this.init();
	this.initEvents();
	this.restore();
}


Menu.prototype.init = function(){
	
};

Menu.prototype.initEvents = function(){
	var self = this;
	$(window).on('beforeunload', function(){
		self.store();
	});
};

Menu.prototype.store = function(){
	var obj = {};
	obj.mediaProviders = this.mediaProviders;
	obj.categories = this.categories;
	
	storage.setItemInLocal('settings', JSON.stringify(obj));
};

Menu.prototype.restore = function(){
	
};


function Settings(){
	this.mediaProviders = 'undefined';
	this.categories = 'undefined';
	
	this.init();
	this.initEvents();
	this.restore();
}

Settings.prototype.init = function(){
	/*if(storage.getItemFromLocal('settings')){
		this.restore();
	}else{
		var self = this;
		$.when(repository.getMediaProviders(), repository.getCategories())
			.then(function(dataA, dataB){
				self.mediaProviders = dataA[0];
				self.categories = dataB[0];
			}, function(){
				alert('error');
			});
	}*/
};

Settings.prototype.initEvents = function(){
	var self = this;
	$(window).on('beforeunload', function(){
		self.store();
	});
};

Settings.prototype.store = function(){
	var obj = {};
	obj.mediaProviders = this.mediaProviders;
	obj.categories = this.categories;
	
	storage.setItemInLocal('settings', JSON.stringify(obj));
};

Settings.prototype.restore = function(){
	var data = storage.getItemFromLocal('settings');
	if(data){
		data = JSON.pars(data);
		this.mediaProviders = data.mediaProviders;
		this.categories = data.categories;
		
		layouter = new Layouter();
	}else{
		var self = this;
		$.when(repository.getMediaProviders(), repository.getCategories())
			.then(function(dataA, dataB){
				self.mediaProviders = dataA[0];
				self.categories = dataB[0];
				
				layouter = new Layouter();
			}, function(){
				alert('error');
			});
	}
};

