var first = 0;

var renderMedia = function(data){
	var $container = $('.container');
	
	for(var i = 0; i < data.length; i++){
		$container.append('<a href="' + data[i].url + '"><img src="' + data[i].image + '" alt="" width="193px" height="193px"/></a>');  
	}
	
	first = data[data.length - 1].id;
};

var loadMedia = function(){
	$.ajax({
		url: "/news/all",
		dataType: 'json',
		success: function(data){
			console.log(data); 
			renderMedia(data);
		}
	});
};

var getLast = function(){
	$.ajax({
		url: "/news/last",
		dataType: 'json',
		cache: true,
		headers:{
			'Cache-Control' : 'max-age=123'
		},
		success: function(data){
			renderMedia(data);
		}
	});
};

var getNext = function(){
	$.ajax({
		url: "/news/next",
		data: {last:last},
		dataType: 'json',
		cache: true,
		headers:{
			'Cache-Control' : 'max-age=123'
		},
		success: function(data){
			renderMedia(data);
		}
	});
};

var getPrev = function(){
	$.ajax({
		url: "/news/prev",
		data: {first:first},
		dataType: 'json',
		cache: true,
		headers:{
			'Cache-Control' : 'max-age=123'
		},
		success: function(data){
			renderMedia(data);
		}
	});
};


$(document).ready(function(){
	$('#loadMore').on("click", function(){
		getPrev();
	});
	
	getLast();
	
	/*var repository = new Repository();
	repository.GET("/news/last", {}).done(function(data){
		console.log(data);
	});*/
	
	/*$('#test').css({
		width: "5000px",
		height: ($(window).height() - 15) + 'px',
		border: "1px solid green"
	});		
	
	(function($){
		document.addEventListener('DOMMouseScroll', function(e){
			var evt = window.event || e;
			var delta = evt.detail? evt.detail*(-120) : evt.wheelDelta;
			var posLeft = $(window).scrollLeft();
			
			if(delta > 0) {
				$(window).scrollLeft(posLeft + 50);
				//$(window).animate({scrollLeft: '+=50'}, 500);
	        }
	        else{
	        	$(window).scrollLeft(posLeft - 50);
	        }
		});
	}($));
	
	document.addEventListener('mousemove', function(e){
		if(e.clientX < 5){
			alert("show menu");
		}
	});*/
	
	//alert(screen.width);
});