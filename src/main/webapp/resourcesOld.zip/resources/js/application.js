(function(window){
	
	var $ = window.jQuery;
	var console = window.console;
	var storage;
	var layouter;
	var repository;
	
	var categories = [9,10,11,12];
	var mediaProviders = [1];

	
	function Settings(){
		this.mediaProviders = 'undefined';
		this.categories = 'undefined';
		
		this.init();
		this.initEvents();
		this.restore();
	}
	
	Settings.prototype.init = function(){
		/*if(storage.getItemFromLocal('settings')){
			this.restore();
		}else{
			var self = this;
			$.when(repository.getMediaProviders(), repository.getCategories())
				.then(function(dataA, dataB){
					self.mediaProviders = dataA[0];
					self.categories = dataB[0];
				}, function(){
					alert('error');
				});
		}*/
	};
	
	Settings.prototype.initEvents = function(){
		var self = this;
		$(window).on('beforeunload', function(){
			self.store();
		});
	};
	
	Settings.prototype.store = function(){
		var obj = {};
		obj.mediaProviders = this.mediaProviders;
		obj.categories = this.categories;
		
		storage.setItemInLocal('settings', JSON.stringify(obj));
	};
	
	Settings.prototype.restore = function(){
		var data = storage.getItemFromLocal('settings');
		if(data){
			data = JSON.pars(data);
			this.mediaProviders = data.mediaProviders;
			this.categories = data.categories;
			
			layouter = new Layouter();
		}else{
			var self = this;
			$.when(repository.getMediaProviders(), repository.getCategories())
				.then(function(dataA, dataB){
					self.mediaProviders = dataA[0];
					self.categories = dataB[0];
					
					layouter = new Layouter();
				}, function(){
					alert('error');
				});
		}
	};
	
	//Settings.prototype.
	
	function Medium(data){
		this.html = 'undefined';		

		this.init(data);
	};

	Medium.prototype.init = function(data){
		for(var key in data){
			this[key] = data[key];
		}	

		this.html = Mustache.to_html($('#mediaTemplate').html(), data);
	};

	function Repository(){};

	Repository.prototype.getCategories = function(){
		return $.ajax({
			 type: 'GET',
			 url: '/news/category/all',
			 dataType: 'json',
		   });
	};
	
	Repository.prototype.getMediaProviders = function(){
		return $.ajax({
			 type: 'GET',
			 url: '/news/mediaProvider/all',
			 dataType: 'json',
		   });
	};
	
	Repository.prototype.getRecent = function(){
		return $.ajax({
				 type: 'GET',
				 url: '/news/recent',
				 data: {categories:categories, mediaProviders:mediaProviders, quantity:20},
				 dataType: 'json',
			   });
	};
	
	Repository.prototype.getBeforeThis = function(data){
		return $.ajax({
				type: 'GET',
				url: '/news/before',
				data: data,
			   });
	};
	
	Repository.prototype.getAfterThis = function(data){
		return $.ajax({
				type: 'GET',
				url: '/news/after',
				data: data,
			   });
	};

	function Storage(){};

	Storage.prototype.getItemFromLocal = function(key){
		return localStorage.getItem(key);
	};
	
	Storage.prototype.setItemInLocal = function(key, value){
		localStorage.setItem(key, value);
	};
	
	Storage.prototype.getItem = function(key){
		return sessionStorage.getItem(key);
	};

	Storage.prototype.setItem = function(key, value){
		sessionStorage.setItem(key, value);
	};

	Storage.prototype.removeItem = function(key){
		sessionStorage.removeItem(key);
	};

	Storage.prototype.clear = function(){
		sessionStorage.clear();
	};


	function Layouter(){
		this.$container = 'undefined';
		this.media = 'undefined';
		
		this.init();
		this.initEvents();
		this.restore();
	};

	Layouter.prototype.init = function(){
		this.$container = $('#mediaContainer');
		this.media = [];
	};

	Layouter.prototype.initEvents = function(){
		var self = this;
	
		$(window)
			.on('beforeunload', function(){	
				self.store();
			});
		
		setInterval(function(){
			repository.getAfterThis({date : self.media[0].date, last : self.media[0].id}).done(function(data){
				self.prepend(data);
			});
		}, 20000);
	};

	Layouter.prototype.store = function(){
		var obj = {};
		obj.media = this.media;
		obj.scrollLeft = this.scrollLeft;

		storage.setItem('layouter', JSON.stringify(obj));
	};

	Layouter.prototype.restore = function(){
		var self = this;
		var json = storage.getItem('layouter');
		if(json){
			var data = JSON.parse(json);
			
			//restore media
			this.append(data['media']);
			
		}else{
			repository.getRecent().done(function(data){
				self.append(data);
			});
		}
	};
	
	Layouter.prototype.append = function(data){
		var medium;
		for(var key in data){
			medium = new Medium(data[key]);
			this.media.push(medium);
			this.render(medium, 'append');
		}
	};
	
	Layouter.prototype.prepend = function(data){
		var medium;
		for(var key in data){
			medium = new Medium(data[key]);
			this.media.splice(0, 0, medium);
			this.render(medium, 'prepend');
		}
	};

	Layouter.prototype.render = function(medium, pos){
		var self = this;
		/*var image = new Image();
		image.onload = function(){
			console.log(image.src);
			switch(pos){
				case 'append':
					self.$container
							.masonry()
							.append(medium.html)
							.masonry('appended', medium.html);
					break;
				case 'prepend':
					self.$container
							.masonry()
							.prepend(medium.html)
							.masonry('prepended', medium.html);
					break;
			}			
		};
		
		image.src = medium.image;*/
		switch(pos){
			case 'append':
				self.$container
						.masonry()
						.append(medium.html)
						.masonry('appended', medium.html);
				break;
			case 'prepend':
				self.$container
						.masonry()
						.prepend(medium.html)
						.masonry('prepended', medium.html);
				break;
		}			
	};

	$(document).ready(function(){
		storage = new Storage();		
		repository = new Repository();
		settings = new Settings();
		//layouter = new Layouter();

		$('#loadMore').on('click', function(){
			var length = layouter.media.length;
			repository.getBeforeThis({date : layouter.media[length - 1].date, first : layouter.media[length - 1].id}).done(function(data){
				layouter.append(data);
			});
		});
	});
}(window));
